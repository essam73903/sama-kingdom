
[العربية]
1. أنشئ حساب Firebase على https://firebase.google.com/
2. فعّل Firestore وقم بنسخ إعدادات المشروع إلى ملف firebase.js
3. استخدم خدمة مثل 000webhost.com لرفع ملفات الموقع
4. اربط صفحة الوظائف بلوحة تحكم Firebase عبر Firebase Hosting أو رفع الملفات مباشرة
5. لإرسال البريد: استخدم Cloud Functions + SendGrid

[English]
1. Create a Firebase account at https://firebase.google.com/
2. Enable Firestore and copy project config to firebase.js
3. Use 000webhost.com or Firebase Hosting to upload your site
4. Link job posting pages to Firestore using firebase.js
5. For email: Use Firebase Cloud Functions + SendGrid
